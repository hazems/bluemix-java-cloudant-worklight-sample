package com.todos_client;

public class GCMIntentService extends com.worklight.androidgap.push.GCMIntentService{
	//Nothing to do here...
}
